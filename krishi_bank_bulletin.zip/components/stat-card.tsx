import { View, Text } from "react-native";
import { cn } from "@/lib/utils";
import { getAchievementColor } from "@/lib/format-utils";

interface StatCardProps {
  label: string;
  value: string;
  rate?: string;
  target?: string;
  className?: string;
}

export function StatCard({ label, value, rate, target, className }: StatCardProps) {
  const rateColor = rate ? getAchievementColor(rate) : undefined;

  return (
    <View
      className={cn(
        "bg-surface rounded-lg p-4 border border-border",
        className
      )}
    >
      <Text className="text-sm text-muted mb-2">{label}</Text>
      <Text className="text-2xl font-bold text-foreground mb-1">{value}</Text>
      {rate && (
        <View className="flex-row items-center gap-2">
          <Text
            className="text-xs font-semibold"
            style={{ color: rateColor }}
          >
            {rate}
          </Text>
          {target && (
            <Text className="text-xs text-muted">
              Target: {target}
            </Text>
          )}
        </View>
      )}
    </View>
  );
}
