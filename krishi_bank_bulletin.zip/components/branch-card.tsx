import { View, Text, Pressable } from "react-native";
import { cn } from "@/lib/utils";
import { getAchievementColor, formatNumber } from "@/lib/format-utils";
import { Branch } from "@/lib/types";

interface BranchCardProps {
  branch: Branch;
  onPress?: () => void;
  className?: string;
}

export function BranchCard({ branch, onPress, className }: BranchCardProps) {
  const depositsColor = getAchievementColor(branch.deposits_rate);
  const loansColor = getAchievementColor(branch.loans_rate);
  const recoveryColor = getAchievementColor(branch.recovery_rate);

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        { opacity: pressed ? 0.7 : 1 },
      ]}
    >
      <View
        className={cn(
          "bg-surface rounded-lg p-4 border border-border mb-3",
          className
        )}
      >
        <Text className="text-lg font-bold text-foreground mb-3">
          {branch.name}
        </Text>

        <View className="gap-2">
          {/* Deposits */}
          <View className="flex-row justify-between items-center">
            <Text className="text-sm text-muted flex-1">Deposits</Text>
            <View className="flex-row items-center gap-2">
              <Text className="text-sm font-semibold text-foreground">
                {formatNumber(branch.deposits_collected)}
              </Text>
              <Text
                className="text-xs font-bold"
                style={{ color: depositsColor }}
              >
                {branch.deposits_rate}
              </Text>
            </View>
          </View>

          {/* Loans */}
          <View className="flex-row justify-between items-center">
            <Text className="text-sm text-muted flex-1">Loans</Text>
            <View className="flex-row items-center gap-2">
              <Text className="text-sm font-semibold text-foreground">
                {formatNumber(branch.loans_disbursed)}
              </Text>
              <Text
                className="text-xs font-bold"
                style={{ color: loansColor }}
              >
                {branch.loans_rate}
              </Text>
            </View>
          </View>

          {/* Recovery */}
          <View className="flex-row justify-between items-center">
            <Text className="text-sm text-muted flex-1">Recovery</Text>
            <View className="flex-row items-center gap-2">
              <Text className="text-sm font-semibold text-foreground">
                {formatNumber(branch.recovery_collected)}
              </Text>
              <Text
                className="text-xs font-bold"
                style={{ color: recoveryColor }}
              >
                {branch.recovery_rate}
              </Text>
            </View>
          </View>
        </View>
      </View>
    </Pressable>
  );
}
