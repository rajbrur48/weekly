/**
 * Format a number as currency (Taka)
 */
export function formatCurrency(value: number): string {
  return `৳ ${value.toLocaleString("en-BD", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

/**
 * Format a number with commas
 */
export function formatNumber(value: number): string {
  return value.toLocaleString("en-BD", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
}

/**
 * Parse percentage string to number
 */
export function parsePercentage(value: string): number {
  return parseFloat(value.replace("%", ""));
}

/**
 * Get color based on achievement rate
 */
export function getAchievementColor(rate: string): string {
  const percentage = parsePercentage(rate);
  if (percentage >= 100) return "#22C55E"; // Success - Green
  if (percentage >= 75) return "#F59E0B"; // Warning - Orange
  return "#EF4444"; // Error - Red
}

/**
 * Format date string
 */
export function formatDate(dateStr: string): string {
  try {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-BD", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } catch {
    return dateStr;
  }
}

/**
 * Calculate percentage
 */
export function calculatePercentage(actual: number, target: number): string {
  if (target === 0) return "0%";
  const percentage = (actual / target) * 100;
  return `${Math.round(percentage)}%`;
}
