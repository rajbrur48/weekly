export interface BulletinMetadata {
  bank_name: string;
  office: string;
  week_no: string;
  date: string;
}

export interface BulletinSummary {
  total_deposits_target: number;
  total_deposits_collected: number;
  deposits_achievement_rate: string;
  total_loans_target: number;
  total_loans_disbursed: number;
  loans_achievement_rate: string;
  total_loans_recovery_target: number;
  total_loans_recovered: number;
  recovery_achievement_rate: string;
}

export interface Branch {
  id: number;
  name: string;
  deposits_target: number;
  deposits_collected: number;
  deposits_rate: string;
  loans_target: number;
  loans_disbursed: number;
  loans_rate: string;
  recovery_target: number;
  recovery_collected: number;
  recovery_rate: string;
}

export interface Bulletin {
  metadata: BulletinMetadata;
  summary: BulletinSummary;
  branches: Branch[];
}
