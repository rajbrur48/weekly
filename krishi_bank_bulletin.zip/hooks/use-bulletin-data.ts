import { useEffect, useState } from "react";
import { Bulletin } from "@/lib/types";
import bulletinData from "@/assets/data/bulletin.json";

export function useBulletinData() {
  const [bulletin, setBulletin] = useState<Bulletin | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      // Load bulletin data from JSON file
      setBulletin(bulletinData as Bulletin);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load bulletin data");
    } finally {
      setLoading(false);
    }
  }, []);

  return { bulletin, loading, error };
}
