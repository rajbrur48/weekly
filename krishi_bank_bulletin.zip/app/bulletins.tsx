import { ScrollView, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useBulletinData } from "@/hooks/use-bulletin-data";

export default function BulletinsScreen() {
  const { bulletin, loading, error } = useBulletinData();

  if (loading) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <Text className="text-foreground">Loading...</Text>
      </ScreenContainer>
    );
  }

  if (error || !bulletin) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <Text className="text-error">Error loading bulletins</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-6">
      <ScrollView>
        <Text className="text-2xl font-bold text-foreground mb-4">
          All Bulletins
        </Text>

        <View className="bg-surface rounded-lg p-4 border border-border">
          <Text className="text-lg font-semibold text-foreground mb-2">
            Week {bulletin.metadata.week_no}
          </Text>
          <Text className="text-sm text-muted mb-3">
            {bulletin.metadata.date}
          </Text>
          <Text className="text-xs text-muted">
            {bulletin.metadata.office}
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
