import { ScrollView, Text, View, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { StatCard } from "@/components/stat-card";
import { BranchCard } from "@/components/branch-card";
import { useBulletinData } from "@/hooks/use-bulletin-data";
import { formatNumber } from "@/lib/format-utils";
import { useRouter } from "expo-router";

export default function HomeScreen() {
  const { bulletin, loading, error } = useBulletinData();
  const router = useRouter();

  if (loading) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <Text className="text-foreground">Loading bulletin data...</Text>
      </ScreenContainer>
    );
  }

  if (error || !bulletin) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <Text className="text-error">Error: {error || "No data available"}</Text>
      </ScreenContainer>
    );
  }

  const topBranches = bulletin.branches.slice(0, 5);

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="bg-primary px-6 py-6">
          <Text className="text-white text-sm font-semibold mb-1">
            {bulletin.metadata.office}
          </Text>
          <Text className="text-white text-2xl font-bold mb-1">
            Krishi Bank Bulletin
          </Text>
          <Text className="text-white text-xs opacity-90">
            Week {bulletin.metadata.week_no} • {bulletin.metadata.date}
          </Text>
        </View>

        {/* Summary Section */}
        <View className="px-6 py-6 gap-3">
          <Text className="text-lg font-bold text-foreground mb-2">
            Summary Statistics
          </Text>

          <StatCard
            label="Deposits Collected"
            value={formatNumber(bulletin.summary.total_deposits_collected)}
            rate={bulletin.summary.deposits_achievement_rate}
            target={formatNumber(bulletin.summary.total_deposits_target)}
          />

          <StatCard
            label="Loans Disbursed"
            value={formatNumber(bulletin.summary.total_loans_disbursed)}
            rate={bulletin.summary.loans_achievement_rate}
            target={formatNumber(bulletin.summary.total_loans_target)}
          />

          <StatCard
            label="Loans Recovered"
            value={formatNumber(bulletin.summary.total_loans_recovered)}
            rate={bulletin.summary.recovery_achievement_rate}
            target={formatNumber(bulletin.summary.total_loans_recovery_target)}
          />
        </View>

        {/* Top Branches */}
        <View className="px-6 py-4">
          <View className="flex-row justify-between items-center mb-4">
            <Text className="text-lg font-bold text-foreground">
              Top Branches
            </Text>
          <Pressable
            onPress={() => router.push("/branches")}
            style={({ pressed }: any) => [{ opacity: pressed ? 0.7 : 1 }]}
          >
            <Text className="text-accent font-semibold">View All</Text>
          </Pressable>
          </View>

          {topBranches.map((branch) => (
            <BranchCard
              key={branch.id}
              branch={branch}
              onPress={() => router.push(`/branch/${branch.id}`)}
            />
          ))}
        </View>

        {/* Action Buttons */}
        <View className="px-6 py-6 gap-3">
          <Pressable
            className="bg-primary rounded-lg py-4 items-center"
            style={({ pressed }: any) => [{ opacity: pressed ? 0.9 : 1 }]}
            onPress={() => router.push("/branches")}
          >
            <Text className="text-white font-semibold text-base">
              View All Bulletins
            </Text>
          </Pressable>

          <Pressable
            className="bg-surface border border-border rounded-lg py-4 items-center"
            style={({ pressed }: any) => [{ opacity: pressed ? 0.7 : 1 }]}
            onPress={() => router.push("/analytics")}
          >
            <Text className="text-foreground font-semibold text-base">
              View Analytics
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
