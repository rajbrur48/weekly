import { ScrollView, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useBulletinData } from "@/hooks/use-bulletin-data";
import { StatCard } from "@/components/stat-card";
import { formatNumber } from "@/lib/format-utils";

export default function AnalyticsScreen() {
  const { bulletin, loading, error } = useBulletinData();

  if (loading) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <Text className="text-foreground">Loading...</Text>
      </ScreenContainer>
    );
  }

  if (error || !bulletin) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <Text className="text-error">Error loading analytics</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-6">
      <ScrollView>
        <Text className="text-2xl font-bold text-foreground mb-4">
          Analytics & Insights
        </Text>

        <View className="gap-3">
          <StatCard
            label="Total Deposits Collected"
            value={formatNumber(bulletin.summary.total_deposits_collected)}
            rate={bulletin.summary.deposits_achievement_rate}
          />

          <StatCard
            label="Total Loans Disbursed"
            value={formatNumber(bulletin.summary.total_loans_disbursed)}
            rate={bulletin.summary.loans_achievement_rate}
          />

          <StatCard
            label="Total Loans Recovered"
            value={formatNumber(bulletin.summary.total_loans_recovered)}
            rate={bulletin.summary.recovery_achievement_rate}
          />

          <Text className="text-lg font-bold text-foreground mt-6 mb-3">
            Branch Performance
          </Text>

          {bulletin.branches.map((branch) => (
            <View
              key={branch.id}
              className="bg-surface rounded-lg p-3 border border-border mb-2"
            >
              <Text className="text-sm font-semibold text-foreground mb-1">
                {branch.name}
              </Text>
              <Text className="text-xs text-muted">
                Deposits: {branch.deposits_rate} • Loans: {branch.loans_rate} • Recovery: {branch.recovery_rate}
              </Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
