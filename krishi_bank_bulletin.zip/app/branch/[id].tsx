import { ScrollView, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useBulletinData } from "@/hooks/use-bulletin-data";
import { StatCard } from "@/components/stat-card";
import { useLocalSearchParams } from "expo-router";
import { formatNumber } from "@/lib/format-utils";

export default function BranchDetailScreen() {
  const { id } = useLocalSearchParams();
  const { bulletin, loading, error } = useBulletinData();

  if (loading) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <Text className="text-foreground">Loading...</Text>
      </ScreenContainer>
    );
  }

  if (error || !bulletin) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <Text className="text-error">Error loading branch details</Text>
      </ScreenContainer>
    );
  }

  const branch = bulletin.branches.find((b) => b.id === parseInt(id as string));

  if (!branch) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <Text className="text-error">Branch not found</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-6">
      <ScrollView>
        <Text className="text-2xl font-bold text-foreground mb-2">
          {branch.name}
        </Text>
        <Text className="text-sm text-muted mb-6">
          Week {bulletin.metadata.week_no} • {bulletin.metadata.date}
        </Text>

        <Text className="text-lg font-bold text-foreground mb-3">
          Performance Metrics
        </Text>

        <StatCard
          label="Deposits Collected"
          value={formatNumber(branch.deposits_collected)}
          rate={branch.deposits_rate}
          target={formatNumber(branch.deposits_target)}
          className="mb-3"
        />

        <StatCard
          label="Loans Disbursed"
          value={formatNumber(branch.loans_disbursed)}
          rate={branch.loans_rate}
          target={formatNumber(branch.loans_target)}
          className="mb-3"
        />

        <StatCard
          label="Loans Recovered"
          value={formatNumber(branch.recovery_collected)}
          rate={branch.recovery_rate}
          target={formatNumber(branch.recovery_target)}
          className="mb-3"
        />

        <Text className="text-lg font-bold text-foreground mt-6 mb-3">
          Comparison with Average
        </Text>

        <View className="bg-surface rounded-lg p-4 border border-border">
          <Text className="text-sm text-muted mb-2">
            This branch is performing relative to the regional average across all metrics.
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
