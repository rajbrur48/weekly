/** @type {const} */
const themeColors = {
  primary: { light: '#1B7D3C', dark: '#1B7D3C' },
  accent: { light: '#0066CC', dark: '#0066CC' },
  background: { light: '#ffffff', dark: '#1A1A1A' },
  surface: { light: '#F5F5F5', dark: '#2D2D2D' },
  foreground: { light: '#1A1A1A', dark: '#FFFFFF' },
  muted: { light: '#666666', dark: '#CCCCCC' },
  border: { light: '#E5E7EB', dark: '#404040' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
